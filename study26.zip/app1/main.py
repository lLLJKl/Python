from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from kafka import KafkaProducer
from settings import settings

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


pd = KafkaProducer(bootstrap_servers=settings.kafka_server)

@app.get("/")
def read_root():
    return {"msg": "Producer"}

@app.post("/pd")
def producer(msg: str):
    pd.send(settings.kafka_topic, msg.encode("utf-8"))
    pd.flush()
    return {"status": True}
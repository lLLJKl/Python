import { useState } from "react"
import axios from 'axios';

const EmailForm =()=>{
    const [msg,setMsg]=useState("")
    const [email, setEmail]=useState("")

    const sendToKafka = async () => {
    await axios.post(`http://localhost:8001/pd?msg=${msg}`); 
    alert("Kafka로 메시지 전송 완료!");
    };

    const sendDirectEmail = async () => {
    await axios.post('http://localhost:8003/email', {
      email: email,
    });
    alert("이메일 직접 발송 완료!");
    };

    return(
        <>
        <div style={{ padding: '50px' }}>
            <h1>통합 전송 센터</h1>
      
        <section>
        <h3>1. Kafka Producer </h3>
        <input value={msg} onChange={(e)=>setMsg(e.target.value)} placeholder="메시지 입력"/>
        <button onClick={sendToKafka}>Kafka 전송</button>
        </section>

        <hr />

        <section>
        <h3>2. Email 직접 발송 </h3>
        <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="이메일 주소"/>
        <button onClick={sendDirectEmail}>이메일 발송</button>
        </section>
        </div>
        </>
    )
}
export default EmailForm

